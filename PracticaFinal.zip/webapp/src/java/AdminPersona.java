
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import models.ClienteDAO;
import models.Cliente;
import models.Persona;
import models.PersonaDAO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mateo.llano
 */
public class AdminPersona extends HttpServlet {

    ClienteDAO clienteDAO = new ClienteDAO();
    Cliente clie = new Cliente();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher view = request.getRequestDispatcher("registro.jsp");
        view.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("idWeb");
        String PrimerNombre = request.getParameter("nombre");
        String SegundoNombre = request.getParameter("2doNombre");
        String PrimerApellido = request.getParameter("apellido");
        String SegundoApellido = request.getParameter("2doApellido");
        String Telefono = request.getParameter("tel");
        String Correo = request.getParameter("correo");

        clie.setId(id);
        clie.setPrimerNombre(PrimerNombre);
        clie.setSegundoNombre(SegundoNombre);
        clie.setPrimerApellido(PrimerApellido);
        clie.setSegundoApellido(SegundoApellido);
        clie.setTelefono(Telefono);
        clie.setCorreo(Correo);
        clienteDAO.agregar(clie);

        RequestDispatcher view = request.getRequestDispatcher("registro.jsp");
        request.setAttribute("mensaje", "Persona agregada satisfactoriamente");
        view.forward(request, response);
    }

}
